import React, { useCallback, useEffect, useMemo, useState } from "react";
import { TournamentDB } from "./TournamentDB";
import { Logik } from "./Logik";
import { AutodartsApi } from "./AutodartsApi";

const db = new TournamentDB();
const logic = new Logik();
const autodartsApi = new AutodartsApi();

function handleAutodartsApiError(error, fallbackMessage) {
  console.error(error);

  if (error?.code === "TOKEN_REFRESH_REQUIRED") {
    alert("Dein Autodarts-Login ist abgelaufen oder ungültig. Bitte lade die Seite neu.");
    return true;
  }

  if (fallbackMessage) {
    alert(fallbackMessage);
    return true;
  }

  return false;
}

const SCORE_OPTIONS = [121, 170, 301, 501, 701, 901];
const MODE_OPTIONS = ["Straight", "Double", "Master"];
const MAX_ROUNDS_OPTIONS = [15, 20, 50, 80];
const BULL_MODE_OPTIONS = ["25/50", "50/50"];
const BULL_OFF_OPTIONS = ["Off", "Normal", "Official"];
const MATCH_MODE_OPTIONS = ["Legs", "Sets"];
const GROUP_SIZE_OPTIONS = [3, 4, 5, 6, 8, 10, 12, 24, 32];
const QUALIFIER_OPTIONS = [1, 2, 4, 8, 16, 32];
const LEGS_OPTIONS = [1, 3, 5, 7, 9, 11];
const SETS_OPTIONS = [1, 3, 5, 7];
const LEGS_OF_SET_OPTIONS = [1, 3, 5];
const DEFAULT_PLAYERS = [
  "Anna",
  "Bernd",
  "Christian",
  "Doris",
  "Erika",
  "Frank",
  "Gabi",
  "Hans",
  "Ingrid",
  "Jürgen",
  "Karin",
  "Lars",
  "Monika",
  "Norbert",
  "Olga",
  "Peter",
  "Petra",
  "Ralf",
  "Sabine",
  "Thomas",
  "Ursula",
  "Volker",
  "Waltraud",
  "Xaver",
  "Yvonne",
  "Zoe",
  "Alexander",
  "Beate",
  "Claus",
  "Diana",
  "Erich",
  "Frieda",
  "Gerhard",
  "Hilde",
  "Igor",
  "Jutta",
  "Karl",
  "Lisa",
  "Manfred",
  "Nina",
  "Otto",
  "Paula",
  "Quirin",
  "Renate",
  "Stefan",
  "Tanja",
  "Uwe",
  "Verena",
  "Wolfgang",
  "Yasin",
];

const activeMatchWatchers = new Set();
const cancelledMatchWatchers = new Set();
const LAST_TOURNAMENT_STORAGE_KEY = "adTournamentLastTournamentId";

const isRealPlayer = (player) => player && typeof player === "object" && player.type === "player";
const isBye = (player) => player && typeof player === "object" && player.type === "bye";

function getDisplayName(player) {
  if (!player) return "—";

  if (typeof player === "string") {
    if (player === "__BYE__") return "Freilos";
    if (!Number.isNaN(Number(player))) return `Sieger Spiel ${player}`;
    return player;
  }

  if (player.type === "bye") return "Freilos";
  if (player.type === "player") return player.name || "—";
  if (player.type === "match") return `Sieger Spiel ${player.ref}`;
  if (player.type === "qualifier") return player.ref;
  if (player.name) return player.name;

  return "—";
}

function formatStatValue(value, digits = 1) {
  const num = Number(value || 0);
  return Number.isFinite(num) ? num.toFixed(digits) : (0).toFixed(digits);
}

function extractFinalPlayerStatsFromAutodartsStats(stats) {
  const players = stats?.players || [];
  const matchStats = stats?.matchStats || [];

  return matchStats.map((entry, index) => ({
    name: players[index]?.name || null,
    stats: entry || null,
    index,
    isWinner: stats?.winner === index,
  }));
}

function extractMatchResultFromStats(stats, match) {
  const winnerIndex = stats?.winner;

  if (typeof winnerIndex !== "number") {
    throw new Error("Kein Sieger in den Match-Stats gefunden");
  }

  const winnerPlayer = stats?.players?.[winnerIndex];
  const loserIndex = winnerIndex === 0 ? 1 : 0;
  const loserPlayer = stats?.players?.[loserIndex] || null;

  if (!winnerPlayer) {
    throw new Error("Sieger konnte nicht aus den Match-Stats gelesen werden");
  }

  const normalizePlayer = (matchPlayer, statsPlayer) => {
    if (!matchPlayer) return null;

    return {
      ...matchPlayer,
      name: statsPlayer?.name || matchPlayer.name || "—",
    };
  };

  let winner = null;
  let loser = null;

  if (match?.player1?.name === winnerPlayer.name) {
    winner = normalizePlayer(match.player1, winnerPlayer);
    loser = normalizePlayer(match.player2, loserPlayer);
  } else if (match?.player2?.name === winnerPlayer.name) {
    winner = normalizePlayer(match.player2, winnerPlayer);
    loser = normalizePlayer(match.player1, loserPlayer);
  } else {
    winner = {
      type: "player",
      id: null,
      name: winnerPlayer.name,
      groupId: null,
    };

    loser = loserPlayer
      ? {
          type: "player",
          id: null,
          name: loserPlayer.name,
          groupId: null,
        }
      : null;
  }

  return { winner, loser };
}

function getPlayerScore(match, slot, matchMode = "Legs") {
  if (!match) return null;

  const score = slot === "player1" ? match.scorePlayer1 : match.scorePlayer2;
  if (score === null || score === undefined) return null;

  if (typeof score === "object") {
    const sets = typeof score.sets === "number" ? score.sets : 0;
    const legs = typeof score.legs === "number" ? score.legs : 0;
    return matchMode === "Sets" ? `${sets}:${legs}` : String(legs);
  }

  if (typeof score === "number" || typeof score === "string") {
    return String(score);
  }

  return null;
}

function compareMatchNumbers(a, b) {
  const parseMatchNumber = (value) => {
    const str = String(value);

    const groupMatch = str.match(/^([A-Z])-(\d+)$/);
    if (groupMatch) {
      return {
        type: "group",
        group: groupMatch[1].charCodeAt(0),
        num: Number(groupMatch[2]),
      };
    }

    if (!Number.isNaN(Number(str))) {
      return {
        type: "ko",
        group: 999,
        num: Number(str),
      };
    }

    return {
      type: "other",
      group: 9999,
      num: 9999,
    };
  };

  const parsedA = parseMatchNumber(a);
  const parsedB = parseMatchNumber(b);

  if (parsedA.group !== parsedB.group) {
    return parsedA.group - parsedB.group;
  }

  return parsedA.num - parsedB.num;
}

function sortMatchesByMatchNumber(matches) {
  return [...matches].sort((a, b) => compareMatchNumbers(a.matchNumber, b.matchNumber));
}

function groupMatchesByRound(matches) {
  const roundMap = new Map();

  for (const match of matches) {
    const roundKey = String(match.round);
    if (!roundMap.has(roundKey)) {
      roundMap.set(roundKey, []);
    }
    roundMap.get(roundKey).push(match);
  }

  return [...roundMap.entries()]
    .sort((a, b) => Number(a[0]) - Number(b[0]))
    .map(([round, roundMatches]) => ({
      round: Number(round),
      matches: roundMatches,
    }));
}

function buildGroupTables(matches = [], groups = [], qualifiedPerGroup = 2) {
  const groupMatches = matches.filter((match) => !!match.group);
  const groupNames = [
    ...new Set([
      ...groupMatches.map((match) => match.group).filter(Boolean),
      ...groups.map((group) => group?.name).filter(Boolean),
    ]),
  ];

  return groupNames.map((groupName) => {
    const matchesOfGroup = sortMatchesByMatchNumber(
      groupMatches.filter((match) => match.group === groupName),
    );

    const table = new Map();

    const ensurePlayer = (player) => {
      if (!player || player.type !== "player") return null;

      const key = String(player.id || player.name || "")
        .trim()
        .toLowerCase();
      if (!key) return null;

      if (!table.has(key)) {
        table.set(key, {
          key,
          player,
          played: 0,
          wins: 0,
          losses: 0,
          points: 0,
          legsWon: 0,
          legsLost: 0,
          legDiff: 0,
          setsWon: 0,
          setsLost: 0,
          setDiff: 0,
        });
      }

      return table.get(key);
    };

    for (const match of matchesOfGroup) {
      ensurePlayer(match.player1);
      ensurePlayer(match.player2);

      if (match.status !== "finished") continue;
      if (match.player1?.type !== "player" || match.player2?.type !== "player") continue;

      const entry1 = ensurePlayer(match.player1);
      const entry2 = ensurePlayer(match.player2);
      if (!entry1 || !entry2) continue;

      entry1.played += 1;
      entry2.played += 1;

      const score1 = Number(match.scorePlayer1?.legs ?? match.scorePlayer1 ?? 0) || 0;
      const score2 = Number(match.scorePlayer2?.legs ?? match.scorePlayer2 ?? 0) || 0;
      const sets1 = Number(match.scorePlayer1?.sets ?? 0) || 0;
      const sets2 = Number(match.scorePlayer2?.sets ?? 0) || 0;

      entry1.legsWon += score1;
      entry1.legsLost += score2;
      entry2.legsWon += score2;
      entry2.legsLost += score1;

      entry1.setsWon += sets1;
      entry1.setsLost += sets2;
      entry2.setsWon += sets2;
      entry2.setsLost += sets1;

      const winnerKey = String(match.winner?.id || match.winner?.name || "")
        .trim()
        .toLowerCase();

      if (winnerKey && winnerKey === entry1.key) {
        entry1.wins += 1;
        entry1.points += 2;
        entry2.losses += 1;
      } else if (winnerKey && winnerKey === entry2.key) {
        entry2.wins += 1;
        entry2.points += 2;
        entry1.losses += 1;
      }
    }

    const standings = [...table.values()]
      .map((entry) => ({
        ...entry,
        legDiff: entry.legsWon - entry.legsLost,
        setDiff: entry.setsWon - entry.setsLost,
      }))
      .sort((a, b) => {
        const pointsDiff = b.points - a.points;
        if (pointsDiff !== 0) return pointsDiff;

        const winsDiff = b.wins - a.wins;
        if (winsDiff !== 0) return winsDiff;

        const legDiff = b.legDiff - a.legDiff;
        if (legDiff !== 0) return legDiff;

        const legsWonDiff = b.legsWon - a.legsWon;
        if (legsWonDiff !== 0) return legsWonDiff;

        const setDiff = b.setDiff - a.setDiff;
        if (setDiff !== 0) return setDiff;

        return String(a.player?.name || "").localeCompare(String(b.player?.name || ""), "de", {
          sensitivity: "base",
        });
      })
      .map((entry, index) => ({
        ...entry,
        rank: index + 1,
        isQualified: index < qualifiedPerGroup,
      }));

    const finishedMatches = matchesOfGroup.filter((match) => match.status === "finished").length;

    return {
      name: groupName,
      matches: matchesOfGroup,
      standings,
      totalMatches: matchesOfGroup.length,
      finishedMatches,
      isComplete: matchesOfGroup.length > 0 && finishedMatches === matchesOfGroup.length,
    };
  });
}

function isTournamentFinished(matches = []) {
  if (!Array.isArray(matches) || matches.length === 0) return false;
  return matches.every((match) => match.status === "finished");
}

function sortPlayersForFinalTable(players = []) {
  return [...players].sort((a, b) => {
    const pointsDiff = Number(b.points || 0) - Number(a.points || 0);
    if (pointsDiff !== 0) return pointsDiff;

    const winsDiff = Number(b.wins || 0) - Number(a.wins || 0);
    if (winsDiff !== 0) return winsDiff;

    const legsDiffA = Number(a.legsWon || 0) - Number(a.legsLost || 0);
    const legsDiffB = Number(b.legsWon || 0) - Number(b.legsLost || 0);
    if (legsDiffB !== legsDiffA) return legsDiffB - legsDiffA;

    const setsDiffA = Number(a.setsWon || 0) - Number(a.setsLost || 0);
    const setsDiffB = Number(b.setsWon || 0) - Number(b.setsLost || 0);
    if (setsDiffB !== setsDiffA) return setsDiffB - setsDiffA;

    return Number(b.average || 0) - Number(a.average || 0);
  });
}

function canStartMatch(match) {
  if (!match || match.status !== "pending") return false;
  return isRealPlayer(match.player1) && isRealPlayer(match.player2);
}

function isLiveMatch(match) {
  return !!match && ["started", "live", "running"].includes(match.status);
}

function canGiveUp(match) {
  if (!match || match.status === "finished" || isLiveMatch(match)) return false;
  return isRealPlayer(match.player1) && isRealPlayer(match.player2);
}

function canEditResult(match) {
  if (!match || !["finished", "aborted"].includes(match.status)) return false;
  return isRealPlayer(match.player1) && isRealPlayer(match.player2);
}

function canRestartMatch(match) {
  if (!match || !["finished", "aborted"].includes(match.status)) return false;
  return isRealPlayer(match.player1) && isRealPlayer(match.player2);
}

function getStatusLabel(status) {
  if (status === "finished") return "Fertig";
  if (status === "aborted") return "Abgebrochen";
  if (status === "started" || status === "live" || status === "running") return "Live";
  if (status === "pending") return "Offen";
  return status || "Unbekannt";
}

function getStatusClass(status) {
  if (status === "finished") return "status-finished";
  if (status === "aborted") return "status-default";
  if (status === "started" || status === "live" || status === "running") return "status-live";
  if (status === "pending") return "status-pending";
  return "status-default";
}

async function watchMatchUntilFinished({
  tournamentId,
  match,
  boardDocId,
  lobbyId,
  intervalMs = 4000,
  timeoutMs = 1000 * 60 * 60 * 4,
}) {
  if (!tournamentId || !match?.id || !lobbyId) return;

  const watcherKey = `${tournamentId}:${match.id}`;

  cancelledMatchWatchers.delete(watcherKey);
  if (activeMatchWatchers.has(watcherKey)) return;

  activeMatchWatchers.add(watcherKey);
  const startedAt = Date.now();

  const stopWatching = () => {
    activeMatchWatchers.delete(watcherKey);
    cancelledMatchWatchers.delete(watcherKey);
  };

  const tick = async () => {
    if (cancelledMatchWatchers.has(watcherKey)) {
      stopWatching();
      return;
    }

    if (Date.now() - startedAt > timeoutMs) {
      console.warn("Match watcher timeout:", lobbyId);
      stopWatching();
      return;
    }

    try {
      const stats = await autodartsApi.getMatchStats(lobbyId);

      if (!stats) {
        setTimeout(tick, intervalMs);
        return;
      }

      const scorePlayer1 = stats?.scores?.[0] ?? null;
      const scorePlayer2 = stats?.scores?.[1] ?? null;

      await db.saveMatchScore(tournamentId, match.id, {
        lobbyId,
        boardId: match.boardId || null,
        scorePlayer1,
        scorePlayer2,
      });

      if (stats?.finishedAt == null) {
        setTimeout(tick, intervalMs);
        return;
      }

      const result = extractMatchResultFromStats(stats, match);

      await db.setMatchFinished(tournamentId, match.id, result.winner, result.loser, {
        lobbyId,
        boardId: match.boardId || null,
        scorePlayer1,
        scorePlayer2,
        finalPlayerStats: extractFinalPlayerStatsFromAutodartsStats(stats),
        finishedAt: stats?.finishedAt || new Date().toISOString(),
        resultSource: "autodarts",
      });

      if (boardDocId) {
        await db.releaseBoard(tournamentId, boardDocId);
      }

      stopWatching();
    } catch (error) {
  console.error("watchMatchUntilFinished error", error);

  if (error?.code === "TOKEN_REFRESH_REQUIRED") {
    alert("Dein Autodarts-Login ist abgelaufen oder ungültig. Bitte lade die Seite neu.");
    stopWatching();
    return;
  }

  setTimeout(tick, intervalMs);
}
  };

  tick();
}

function CollapsibleSection({
  title,
  subtitle,
  badge = null,
  defaultOpen = true,
  actions = null,
  className = "",
  children,
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className={`collapsible-section ${className} ${isOpen ? "is-open" : "is-closed"}`.trim()}>
      <button type="button" className="collapse-toggle" onClick={() => setIsOpen((prev) => !prev)}>
        <div className="collapse-toggle-left">
          <span className={`collapse-chevron ${isOpen ? "open" : ""}`}>⌄</span>
          <div className="collapse-title-wrap">
            <strong>{title}</strong>
            {subtitle && <span className="section-subtitle">{subtitle}</span>}
          </div>
        </div>

        <div className="collapse-toggle-right">
          {badge !== null && <span className="group-block-count">{badge}</span>}
          {actions ? <span className="collapse-inline-actions">{actions}</span> : null}
        </div>
      </button>

      {isOpen && <div className="collapsible-content">{children}</div>}
    </div>
  );
}

function GroupStandingsTable({ standings, qualifiedPerGroup }) {
  if (!standings?.length) return null;

  return (
    <div className="group-standings-card">
      <div className="group-standings-head">
        <strong>Tabelle</strong>
        <span>{qualifiedPerGroup} Qualifikanten</span>
      </div>

      <div className="group-standings-table-wrap">
        <table className="group-standings-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Spieler</th>
              <th>Sp</th>
              <th>S</th>
              <th>N</th>
              <th>Pkte</th>
              <th>Legs</th>
              <th>Diff</th>
            </tr>
          </thead>
          <tbody>
            {standings.map((entry) => (
              <tr key={entry.key} className={entry.isQualified ? "qualified-row" : ""}>
                <td>{entry.rank}</td>
                <td>
                  <div className="group-player-cell">
                    <span>{entry.player?.name || "—"}</span>
                    {entry.rank <= qualifiedPerGroup && <span className="qualified-badge">Q</span>}
                  </div>
                </td>
                <td>{entry.played}</td>
                <td>{entry.wins}</td>
                <td>{entry.losses}</td>
                <td>{entry.points}</td>
                <td>
                  {entry.legsWon}:{entry.legsLost}
                </td>
                <td>{entry.legDiff > 0 ? `+${entry.legDiff}` : entry.legDiff}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function MatchPlayerRow({ match, slot, matchMode, onGiveUpMatch }) {
  const player = slot === "player1" ? match.player1 : match.player2;
  const score = getPlayerScore(match, slot, matchMode);
  const isWinner = match?.winner?.name && match?.winner?.name === player?.name;

  return (
    <div className={`player-row compact-player-row ${isWinner ? "winner-row" : ""}`}>
      <div className="player-row-main">
        <span className="player-name-text">{getDisplayName(player)}</span>
        {isWinner && <span className="winner-badge">Sieger</span>}
      </div>

      <div className="player-row-actions">
        {score !== null && <span className="player-score">{score}</span>}
        {canGiveUp(match) && (
          <button type="button" className="forfeit-btn" onClick={() => onGiveUpMatch(match, slot)}>
            Aufgeben
          </button>
        )}
      </div>
    </div>
  );
}

function MatchCard({
  match,
  matchMode,
  onStartMatch,
  onGiveUpMatch,
  onEditResult,
  onRestartMatch,
  onAbortLiveMatch,
  labelPrefix = "",
}) {
  return (
    <div
      className="match-card compact-card match-card-enhanced"
      key={`${labelPrefix}${match.matchNumber}`}
    >
      <div className="match-head">
        <div className="match-title-stack">
          <span className="match-number">
            {labelPrefix ? `${labelPrefix} ${match.matchNumber}` : match.matchNumber}
          </span>
          {match.group && <span className="match-subline">{match.group}</span>}
        </div>

        <span className={`status-pill ${getStatusClass(match.status)}`}>
          {getStatusLabel(match.status)}
        </span>
      </div>

      <div className="match-body">
        <MatchPlayerRow
          match={match}
          slot="player1"
          matchMode={matchMode}
          onGiveUpMatch={onGiveUpMatch}
        />
        <MatchPlayerRow
          match={match}
          slot="player2"
          matchMode={matchMode}
          onGiveUpMatch={onGiveUpMatch}
        />
      </div>

      <div className="match-foot">
        <span>Sieger</span>
        <span>{getDisplayName(match.winner)}</span>
      </div>

      <div className="match-card-actions">
        {canStartMatch(match) && (
          <button className="start-match-btn compact-btn" onClick={() => onStartMatch(match)}>
            Starten
          </button>
        )}

        {isLiveMatch(match) && match.lobbyId && (
          <>
            <button
              className="secondary-btn compact-btn open-match"
              onClick={() => {
                const matchUrl = `https://play.autodarts.io/matches/${match.lobbyId}`;
                window.open(matchUrl, "_blank", "noopener,noreferrer");
              }}
            >
              Spiel öffnen
            </button>

            <button className="secondary-btn compact-btn" onClick={() => onAbortLiveMatch(match)}>
              Abbrechen
            </button>
          </>
        )}

        {canRestartMatch(match) && (
          <button className="secondary-btn compact-btn" onClick={() => onRestartMatch(match)}>
            Spiel neu starten
          </button>
        )}

        {canEditResult(match) && (
          <button className="secondary-btn compact-btn" onClick={() => onEditResult(match)}>
            {match.status === "aborted" ? "Ergebnis eingeben" : "Ergebnis korrigieren"}
          </button>
        )}
      </div>
    </div>
  );
}

function BoardOverview({ boards, matches, onReleaseBoard }) {
  if (!boards?.length) return null;

  const getMatchLabel = (match) => {
    if (!match) return "Kein Spiel";
    return `Spiel ${match.matchNumber}: ${getDisplayName(match.player1)} vs. ${getDisplayName(match.player2)}`;
  };

  return (
    <div className="tree-section">
      <CollapsibleSection
        title="Boards"
        subtitle="Live-Zuordnung und manuelle Freigabe"
        badge={`${boards.length} Boards`}
        defaultOpen={false}
      >
        <div className="group-match-grid board-grid">
          {boards.map((board) => {
            const currentMatch = matches.find((match) => match.id === board.currentMatchId);
            const isBusy = board.status !== "free" || !!board.currentMatchId;

            return (
              <div key={board.id} className="match-card compact-card board-card">
                <div className="match-head">
                  <div className="match-title-stack">
                    <span className="board-name">{board.name || board.boardId || board.id}</span>
                    <span className="match-subline">Board</span>
                  </div>

                  <span className={`status-pill ${isBusy ? "status-live" : "status-finished"}`}>
                    {isBusy ? "Belegt" : "Frei"}
                  </span>
                </div>

                <div className="board-meta-list">
                  <div className="board-meta-row">
                    <span>Board-ID</span>
                    <span>{board.boardId || board.id}</span>
                  </div>

                  <div className="board-meta-row">
                    <span>Aktuelles Spiel</span>
                    <span>{getMatchLabel(currentMatch)}</span>
                  </div>
                </div>

                {isBusy && (
                  <button
                    className="secondary-btn compact-btn"
                    onClick={() => onReleaseBoard(board, currentMatch)}
                  >
                    Manuell freigeben
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </CollapsibleSection>
    </div>
  );
}

function OverviewStats({ matches, boards, playersCount, mode }) {
  const totalMatches = matches.length;
  const finishedMatches = matches.filter((m) => m.status === "finished").length;
  const liveMatches = matches.filter((m) =>
    ["started", "live", "running"].includes(m.status),
  ).length;
  const pendingMatches = matches.filter((m) => m.status === "pending").length;

  const totalBoards = boards.length;
  const freeBoardCount = boards.filter((b) => !b.currentMatchId && b.status === "free").length;
  const busyBoards = totalBoards - freeBoardCount;

  const cards = [
    { label: "Spieler", value: playersCount },
    { label: "Modus", value: mode === "KO" ? "KO" : "Gruppen + KO" },
    { label: "Spiele gesamt", value: totalMatches },
    { label: "Offen", value: pendingMatches },
    { label: "Live", value: liveMatches },
    { label: "Fertig", value: finishedMatches },
    { label: "Freie Boards", value: freeBoardCount },
    { label: "Belegte Boards", value: busyBoards },
  ];

  return (
    <CollapsibleSection
      title="Übersicht"
      subtitle="Turnier- und Boardstatus auf einen Blick"
      badge={`${totalMatches} Spiele`}
      className="overview-collapsible"
      defaultOpen={false}
    >
      <div className="overview-stats-grid">
        {cards.map((card) => (
          <div className="overview-stat-card" key={card.label}>
            <div className="overview-stat-label">{card.label}</div>
            <div className="overview-stat-value">{card.value}</div>
          </div>
        ))}
      </div>
    </CollapsibleSection>
  );
}

function FinalStandingsTable({ matches, players, tournamentName }) {
  const tournamentFinished = useMemo(() => isTournamentFinished(matches), [matches]);

  const sortedPlayers = useMemo(() => sortPlayersForFinalTable(players), [players]);

  if (!tournamentFinished || !sortedPlayers.length) return null;

  return (
    <div className="tree-section">
      <CollapsibleSection
        title="Abschlusstabelle"
        subtitle={`Endstand von ${tournamentName || "dem Turnier"}`}
        badge={`${sortedPlayers.length} Spieler`}
        defaultOpen={true}
      >
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 1100 }}>
            <thead>
              <tr>
                {[
                  "Platz",
                  "Spieler",
                  "Siege",
                  "Niederlagen",
                  "Legs",
                  "Sets",
                  "Average",
                  "Checkout %",
                  "60+",
                  "100+",
                  "140+",
                  "171+/180",
                  "Bestes Checkout",
                ].map((head) => (
                  <th
                    key={head}
                    style={{
                      textAlign: "left",
                      padding: "10px 12px",
                      borderBottom: "2px solid rgba(255,255,255,0.14)",
                      color: "#dbe8ff",
                      fontSize: 12,
                      textTransform: "uppercase",
                      letterSpacing: "0.06em",
                    }}
                  >
                    {head}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sortedPlayers.map((player, index) => {
                const rank = index + 1;
                const cellBackground = rank <= 3 ? "rgba(255,255,255,0.03)" : "transparent";

                return (
                  <tr key={player.id || player.name}>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        fontWeight: 700,
                      }}
                    >
                      {rank}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        fontWeight: 700,
                      }}
                    >
                      {player.name}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {Number(player.wins || 0)}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {Number(player.losses || 0)}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {Number(player.legsWon || 0)} / {Number(player.legsLost || 0)}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {Number(player.setsWon || 0)} / {Number(player.setsLost || 0)}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {formatStatValue(player.average, 1)}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {formatStatValue(player.checkoutPercent, 1)}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {Number(player.plus60 || 0)}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {Number(player.plus100 || 0)}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {Number(player.plus140 || 0)}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {Number(player.plus171Or180 || 0)}
                    </td>
                    <td
                      style={{
                        border: "2px solid rgba(255,255,255,0.14)",
                        padding: "10px 12px",
                        textAlign: "center",
                        background: cellBackground,
                      }}
                    >
                      {Number(player.bestCheckout || 0)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CollapsibleSection>
    </div>
  );
}

function TournamentTree({
  matches,
  groups,
  mode,
  matchMode,
  qualifiedPerGroup,
  onStartMatch,
  onGiveUpMatch,
  onEditResult,
  onRestartMatch,
  onAbortLiveMatch,
}) {
  const groupedRounds = useMemo(() => groupMatchesByRound(matches), [matches]);
  const groupMatches = useMemo(
    () => sortMatchesByMatchNumber(matches.filter((match) => match.group)),
    [matches],
  );

  const groupTables = useMemo(
    () => buildGroupTables(matches, groups, qualifiedPerGroup),
    [matches, groups, qualifiedPerGroup],
  );

  if (!matches?.length) return null;

  return (
    <div className="tree-wrapper">
      {mode === "GROUP_KO" && groupMatches.length > 0 && (
        <div className="tree-section">
          <CollapsibleSection
            title="Gruppenphase"
            subtitle="Alle Gruppenspiele mit aktueller Tabelle"
            badge={`${groupMatches.length} Spiele`}
          >
            <div className="group-sections">
              {groupTables.map((groupTable) => (
                <div className="group-block" key={groupTable.name}>
                  <div className="group-block-head">
                    <div>
                      <div className="group-block-title">{groupTable.name}</div>
                      <div className="group-block-count">
                        {groupTable.finishedMatches}/{groupTable.totalMatches} Spiele fertig
                      </div>
                    </div>
                    <div className="group-block-count">
                      {groupTable.isComplete ? "Komplett" : "Laufend"}
                    </div>
                  </div>

                  <div className="group-block-layout">
                    <GroupStandingsTable
                      standings={groupTable.standings}
                      qualifiedPerGroup={qualifiedPerGroup}
                    />

                    <div className="group-match-grid">
                      {groupTable.matches.map((match) => (
                        <MatchCard
                          key={`group-${match.matchNumber}`}
                          match={match}
                          matchMode={matchMode}
                          onStartMatch={onStartMatch}
                          onGiveUpMatch={onGiveUpMatch}
                          onEditResult={onEditResult}
                          onRestartMatch={onRestartMatch}
                          onAbortLiveMatch={onAbortLiveMatch}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CollapsibleSection>
        </div>
      )}

      <div className="tree-section">
        <CollapsibleSection
          title={mode === "KO" ? "KO-Phase" : "Finalrunde"}
          subtitle="Runde für Runde im Turnierbaum"
          badge={`${groupedRounds.length} Runden`}
        >
          <div className="bracket compact-bracket">
            {groupedRounds
              .filter((roundBlock) =>
                mode === "KO" ? true : roundBlock.matches.some((match) => !match.group),
              )
              .map((roundBlock) => (
                <div
                  className="round-column compact-round-column"
                  key={`round-${roundBlock.round}`}
                >
                  <div className="round-title">Runde {roundBlock.round}</div>

                  {sortMatchesByMatchNumber(
                    roundBlock.matches.filter((match) => (mode === "KO" ? true : !match.group)),
                  ).map((match) => (
                    <MatchCard
                      key={`ko-${match.matchNumber}`}
                      match={match}
                      matchMode={matchMode}
                      onStartMatch={onStartMatch}
                      onGiveUpMatch={onGiveUpMatch}
                      onEditResult={onEditResult}
                      onRestartMatch={onRestartMatch}
                      onAbortLiveMatch={onAbortLiveMatch}
                      labelPrefix="Spiel"
                    />
                  ))}
                </div>
              ))}
          </div>
        </CollapsibleSection>
      </div>
    </div>
  );
}

export default function TournamentApp() {
  const [tournamentName, setTournamentName] = useState("Mein Turnier");
  const [mode, setMode] = useState("KO");
  const [baseScore, setBaseScore] = useState(501);
  const [inMode, setInMode] = useState("Straight");
  const [outMode, setOutMode] = useState("Double");
  const [maxRounds, setMaxRounds] = useState(50);
  const [bullMode, setBullMode] = useState("25/50");
  const [bullOffMode, setBullOffMode] = useState("Normal");
  const [matchMode, setMatchMode] = useState("Legs");
  const [legs, setLegs] = useState(3);
  const [sets, setSets] = useState(3);
  const [legsOfSet, setLegsOfSet] = useState(3);
  const [groupSize, setGroupSize] = useState(4);
  const [qualifiers, setQualifiers] = useState(2);
  const [playerName, setPlayerName] = useState("");
  const [players, setPlayers] = useState(DEFAULT_PLAYERS);
  const [tournamentEnvironment, setTournamentEnvironment] = useState("online");

  const [screen, setScreen] = useState("home");
  const [joinCode, setJoinCode] = useState("");
  const [tournamentId, setTournamentId] = useState(null);
  const [tournamentCode, setTournamentCode] = useState("");
  const [matches, setMatches] = useState([]);
  const [groups, setGroups] = useState([]);
  const [playerDocs, setPlayerDocs] = useState([]);
  const [boards, setBoards] = useState([]);
  const [allBoards, setAllBoards] = useState([]);
  const [freeBoards, setFreeBoards] = useState([]);

  const [loadingBoards, setLoadingBoards] = useState(false);
  const [creatingTournament, setCreatingTournament] = useState(false);
  const [joiningTournament, setJoiningTournament] = useState(false);
  const [isRestoringTournament, setIsRestoringTournament] = useState(true);

  const [showBoardDialog, setShowBoardDialog] = useState(false);
  const [selectedBoardId, setSelectedBoardId] = useState("");
  const [selectedMatch, setSelectedMatch] = useState(null);

  const [showSettingsDialog, setShowSettingsDialog] = useState(false);
  const [showEditResultDialog, setShowEditResultDialog] = useState(false);
  const [editingMatch, setEditingMatch] = useState(null);
  const [editingWinnerSlot, setEditingWinnerSlot] = useState("player1");
  const [editingScore1, setEditingScore1] = useState("");
  const [editingScore2, setEditingScore2] = useState("");

  const currentSettings = useMemo(
    () => ({
      baseScore,
      inMode,
      outMode,
      maxRounds,
      bullMode,
      bullOffMode,
      matchMode,
      legs,
      sets,
      legsOfSet,
      groupSize,
      qualifiers,
    }),
    [
      baseScore,
      inMode,
      outMode,
      maxRounds,
      bullMode,
      bullOffMode,
      matchMode,
      legs,
      sets,
      legsOfSet,
      groupSize,
      qualifiers,
    ],
  );

  const applyTournamentState = useCallback((tournament, nextScreen = "tournament") => {
    if (!tournament) return;

    setTournamentId(tournament.id);
    setTournamentCode(tournament.code || "");
    setTournamentName(tournament.name || "Turnier");
    setMode(tournament.type === "GROUP_KO" ? "GROUP_KO" : "KO");

    if (tournament?.settings) {
      const s = tournament.settings;
      if (s.baseScore != null) setBaseScore(Number(s.baseScore) || 501);
      if (s.inMode) setInMode(s.inMode);
      if (s.outMode) setOutMode(s.outMode);
      if (s.maxRounds != null) setMaxRounds(Number(s.maxRounds) || 50);
      if (s.bullMode) setBullMode(s.bullMode);
      if (s.bullOffMode) setBullOffMode(s.bullOffMode);
      if (s.matchMode) setMatchMode(s.matchMode);
      if (s.legs != null) setLegs(Number(s.legs) || 3);
      if (s.sets != null) setSets(Number(s.sets) || 3);
      if (s.legsOfSet != null) setLegsOfSet(Number(s.legsOfSet) || 3);
      if (s.groupSize != null) setGroupSize(Number(s.groupSize) || 4);
      if (s.qualifiers != null) setQualifiers(Number(s.qualifiers) || 2);
    }

    setScreen(nextScreen);
  }, []);

  const handleLeaveTournament = useCallback(() => {
    const shouldLeave = window.confirm("Turnier wirklich verlassen?");
    if (!shouldLeave) return;

    try {
      localStorage.removeItem(LAST_TOURNAMENT_STORAGE_KEY);
    } catch (e) {
      console.warn("LocalStorage cleanup failed", e);
    }

    setTournamentId(null);
    setTournamentCode("");
    setMatches([]);
    setGroups([]);
    setPlayerDocs([]);
    setBoards([]);
    setFreeBoards([]);
    setPlayers(DEFAULT_PLAYERS);
    setScreen("home");
  }, []);

  const handleSaveTournamentSettings = useCallback(async () => {
    try {
      if (!tournamentId) return;

      await db.updateTournamentSetup(tournamentId, {
        name: tournamentName,
        type: mode,
        settings: currentSettings,
      });

      alert("Turniereinstellungen gespeichert.");
    } catch (error) {
      console.error(error);
      alert("Turniereinstellungen konnten nicht gespeichert werden.");
    }
  }, [currentSettings, mode, tournamentId, tournamentName]);

  const loadBoards = useCallback(async () => {
    try {
      setLoadingBoards(true);
      const loadedBoards = await autodartsApi.getBoards();
      setAllBoards(Array.isArray(loadedBoards) ? loadedBoards : []);
    } catch (error) {
      console.error(error);
      alert("Boards konnten nicht geladen werden. Bitte in Autodarts eingeloggt sein.");
    } finally {
      setLoadingBoards(false);
    }
  }, []);

  useEffect(() => {
    const restoreLastTournament = async () => {
      try {
        const savedTournamentId = localStorage.getItem(LAST_TOURNAMENT_STORAGE_KEY);

        if (!savedTournamentId) return;

        const tournament = await db.getTournamentById(savedTournamentId);

        if (!tournament) {
          localStorage.removeItem(LAST_TOURNAMENT_STORAGE_KEY);
          return;
        }

        applyTournamentState(tournament, "tournament");
      } catch (error) {
        console.error("Letztes Turnier konnte nicht wiederhergestellt werden.", error);
      } finally {
        setIsRestoringTournament(false);
      }
    };

    restoreLastTournament();
  }, [applyTournamentState]);

  useEffect(() => {
    loadBoards();
  }, [loadBoards]);

  useEffect(() => {
    if (!tournamentId) return;

    const unsubMatches = db.subscribeToMatches(tournamentId, (items) => {
      setMatches(sortMatchesByMatchNumber(items));
    });

    const unsubBoards = db.subscribeToBoards(tournamentId, (items) => {
      setBoards(items);
    });

    const unsubFreeBoards = db.subscribeToFreeBoards(tournamentId, (items) => {
      setFreeBoards(items);
    });

    const unsubPlayers = db.subscribeToPlayers(tournamentId, (items) => {
      setPlayerDocs(items);
    });

    db.getGroupsByTournamentId(tournamentId).then(setGroups).catch(console.error);

    return () => {
      unsubMatches?.();
      unsubBoards?.();
      unsubFreeBoards?.();
      unsubPlayers?.();
    };
  }, [tournamentId]);

  useEffect(() => {
    if (!allBoards.length) return;

    // Nur beim ersten Laden setzen
    setBoards((prev) => {
      if (prev.length > 0) return prev;

      return allBoards.map((board) => ({
        id: board.id,
        boardId: board.id,
        name: board.name,
      }));
    });
  }, [allBoards]);

  const getBoardDocForMatch = useCallback(
    (match) => {
      if (!match) return null;
      return (
        boards.find(
          (board) =>
            board.currentMatchId === match.id ||
            (match.boardId && String(board.boardId) === String(match.boardId)),
        ) || null
      );
    },
    [boards],
  );

  const addPlayer = () => {
    const trimmed = playerName.trim();
    if (!trimmed) return;

    // ❌ Prüfen ob Name mit Zahl beginnt
    if (/^\d/.test(trimmed)) {
      alert("Der Spielername darf nicht mit einer Zahl beginnen.");
      return;
    }

    // ❌ Prüfen auf Duplikate
    if (players.some((p) => String(p).trim().toLowerCase() === trimmed.toLowerCase())) {
      alert("Dieser Spieler ist bereits vorhanden.");
      return;
    }

    setPlayers((prev) => [...prev, trimmed]);
    setPlayerName("");
  };

  const removePlayer = (name) => {
    setPlayers((prev) => prev.filter((p) => p !== name));
  };

  const createTournament = async () => {
    try {
      if (players.length < 2) {
        alert("Bitte mindestens 2 Spieler hinzufügen.");
        return;
      }

      setCreatingTournament(true);

      const type = mode === "KO" ? "KO" : "GROUP_KO";

      const selectedBoards = allBoards.filter((board) =>
        boards.some((selected) => selected.id === board.id || selected.boardId === board.id),
      );

      if (selectedBoards.length <= 0) {
        alert("Bitte mindestens 1 Board hinzufügen.");
        return;
      }

      const result = await logic.createFullTournament(
        tournamentName.trim() || "Mein Turnier",
        type,
        players,
        selectedBoards,
        groupSize,
        qualifiers,
      );

      await db.updateTournamentSetup(result.id, {
        name: tournamentName.trim() || "Mein Turnier",
        type,
        settings: currentSettings,
      });

      localStorage.setItem(LAST_TOURNAMENT_STORAGE_KEY, result.id);
      applyTournamentState(
        {
          id: result.id,
          code: result.code,
          name: tournamentName.trim() || "Mein Turnier",
          type,
          settings: currentSettings,
        },
        "tournament",
      );
    } catch (error) {
      console.error(error);
      alert("Turnier konnte nicht erstellt werden.");
    } finally {
      setCreatingTournament(false);
    }
  };

  const joinTournament = async () => {
    try {
      if (!joinCode.trim()) return;
      setJoiningTournament(true);

      const tournament = await db.getTournamentByCode(joinCode.trim());
      if (!tournament) {
        alert("Kein Turnier mit diesem Code gefunden.");
        return;
      }

      localStorage.setItem(LAST_TOURNAMENT_STORAGE_KEY, tournament.id);
      applyTournamentState(tournament, "tournament");
    } catch (error) {
      console.error(error);
      alert("Turnier konnte nicht geladen werden.");
    } finally {
      setJoiningTournament(false);
    }
  };

  const handleStartMatch = useCallback(
    async (match) => {
      try {
        if (!tournamentId || !match?.id) return;
        if (!freeBoards.length) {
          alert("Kein freies Board verfügbar.");
          return;
        }

        setSelectedMatch(match);
        setSelectedBoardId(freeBoards[0]?.id || "");
        setShowBoardDialog(true);
      } catch (error) {
        console.error(error);
        alert("Spiel konnte nicht vorbereitet werden.");
      }
    },
    [freeBoards, tournamentId],
  );

  const confirmStartMatch = useCallback(async () => {
    let matchWindow = null;

    try {
      if (!selectedMatch || !tournamentId || !selectedBoardId) return;

      const boardDoc = freeBoards.find((board) => board.id === selectedBoardId);
      if (!boardDoc) {
        if (matchWindow) matchWindow.close();
        alert("Bitte ein freies Board auswählen.");
        return;
      }

      await db.assignBoard(tournamentId, boardDoc, selectedMatch.id);

      const lobby = await autodartsApi.createLobby({
        baseScore,
        inMode,
        outMode,
        bullMode,
        bullOffMode,
        maxRounds,
        legs: matchMode === "Legs" ? legs : legsOfSet,
      });

      const player1Name = selectedMatch.player1?.name;
      const player2Name = selectedMatch.player2?.name;

      await autodartsApi.addPlayerToLobby(lobby.id, {
        name: player1Name,
        boardId: boardDoc.boardId,
      });

      await autodartsApi.addPlayerToLobby(lobby.id, {
        name: player2Name,
        boardId: boardDoc.boardId,
      });

      await db.setMatchStarted(tournamentId, selectedMatch.id, {
        boardId: boardDoc.boardId,
        lobbyId: lobby.id,
      });

      await autodartsApi.startLobby(lobby.id);

      const matchUrl = `https://play.autodarts.io/matches/${lobby.id}`;
      window.open(matchUrl, "_blank", "noopener,noreferrer");

      watchMatchUntilFinished({
        tournamentId,
        match: {
          ...selectedMatch,
          boardId: boardDoc.boardId,
        },
        boardDocId: boardDoc.id,
        lobbyId: lobby.id,
      });

      setShowBoardDialog(false);
      setSelectedBoardId("");
      setSelectedMatch(null);
    } catch (error) {
  if (matchWindow) {
    try {
      matchWindow.close();
    } catch (_) {}
  }

  handleAutodartsApiError(error, "Spiel konnte nicht gestartet werden.");
}
  }, [
    selectedMatch,
    tournamentId,
    selectedBoardId,
    freeBoards,
    baseScore,
    inMode,
    outMode,
    bullMode,
    bullOffMode,
    maxRounds,
    matchMode,
    legs,
    legsOfSet,
  ]);

  const handleGiveUpMatch = useCallback(
    async (match, forfeitingSlot) => {
      try {
        if (!tournamentId || !match?.id) return;

        const winner = forfeitingSlot === "player1" ? match.player2 : match.player1;
        const loser = forfeitingSlot === "player1" ? match.player1 : match.player2;

        if (!winner || winner.type !== "player") return;

        const shouldGiveUp = window.confirm(
          `${getDisplayName(loser)} wirklich aufgeben lassen? ${getDisplayName(winner)} gewinnt das Spiel.`,
        );
        if (!shouldGiveUp) return;

        await db.setMatchFinished(tournamentId, match.id, winner, loser, {
          resultSource: "manual-forfeit",
        });
      } catch (error) {
        console.error(error);
        alert("Spiel konnte nicht per Aufgabe beendet werden.");
      }
    },
    [tournamentId],
  );

  const handleAbortLiveMatch = useCallback(
    async (match) => {
      try {
        if (!tournamentId || !match?.id) return;

        const reallyAbort = window.confirm(`Live-Spiel ${match.matchNumber} wirklich abbrechen?`);
        if (!reallyAbort) return;

        const boardDoc = getBoardDocForMatch(match);
        const boardId = boardDoc?.id || null;

        let stats = null;
        if (match?.lobbyId) {
          try {
            stats = await autodartsApi.getMatchStats(match.lobbyId);
          } catch (error) {
           if (match?.lobbyId) {
  try {
    stats = await autodartsApi.getMatchStats(match.lobbyId);
  } catch (error) {
    if (error?.code === "TOKEN_REFRESH_REQUIRED") {
      throw error;
    }

    console.warn("Stats beim Abbrechen konnten nicht geladen werden", error);
  }
}
          }
        }

        const watcherKey = `${tournamentId}:${match.id}`;
        cancelledMatchWatchers.add(watcherKey);
        activeMatchWatchers.delete(watcherKey);

        if (boardId) {
          await db.releaseBoard(tournamentId, boardId);
        }

        await db.setMatchAborted(tournamentId, match.id, {
          boardId: null,
          lobbyId: null,
          scorePlayer1: stats?.scores?.[0] ?? null,
          scorePlayer2: stats?.scores?.[1] ?? null,
          finalPlayerStats: stats ? extractFinalPlayerStatsFromAutodartsStats(stats) : null,
        });
      } catch (error) {
  handleAutodartsApiError(error, "Live-Spiel konnte nicht abgebrochen werden.");
}
    },
    [getBoardDocForMatch, tournamentId],
  );

  const handleRestartMatch = useCallback(
    async (match) => {
      try {
        if (!tournamentId || !match?.id) return;

        const shouldRestart = window.confirm(
          `Spiel ${match.matchNumber} wirklich neu starten? Der Spielverlauf und alle Folgeeinträge werden zurückgesetzt.`,
        );
        if (!shouldRestart) return;

        const boardDoc = getBoardDocForMatch(match);

        if (boardDoc?.id) {
          await db.releaseBoard(tournamentId, boardDoc.id);
        }

        await db.resetMatchToPending(tournamentId, match.id);

        const watcherKey = `${tournamentId}:${match.id}`;
        cancelledMatchWatchers.add(watcherKey);
        activeMatchWatchers.delete(watcherKey);

        setSelectedMatch({
          ...match,
          status: "pending",
          boardId: null,
          lobbyId: null,
          finalPlayerStats: null,
          startedAt: null,
          finishedAt: null,
          winner: null,
          loser: null,
          scorePlayer1: null,
          scorePlayer2: null,
        });
        setSelectedBoardId(freeBoards[0]?.id || "");
        setShowBoardDialog(true);
      } catch (error) {
        console.error(error);
        alert("Spiel konnte nicht neu gestartet werden.");
      }
    },
    [freeBoards, getBoardDocForMatch, tournamentId],
  );

  const handleOpenEditResult = useCallback((match) => {
    if (!match) return;

    setEditingMatch(match);
    setEditingWinnerSlot(match?.winner?.name === match?.player2?.name ? "player2" : "player1");
    setEditingScore1(
      match?.scorePlayer1 !== null && match?.scorePlayer1 !== undefined
        ? String(match.scorePlayer1?.legs ?? match.scorePlayer1)
        : "",
    );
    setEditingScore2(
      match?.scorePlayer2 !== null && match?.scorePlayer2 !== undefined
        ? String(match.scorePlayer2?.legs ?? match.scorePlayer2)
        : "",
    );
    setShowEditResultDialog(true);
  }, []);

  const handleSaveEditedResult = useCallback(async () => {
    try {
      if (!tournamentId || !editingMatch) return;

      const winner = editingWinnerSlot === "player1" ? editingMatch.player1 : editingMatch.player2;
      const loser = editingWinnerSlot === "player1" ? editingMatch.player2 : editingMatch.player1;

      await db.correctMatchResult(tournamentId, editingMatch.id, {
        winner,
        loser,
        scorePlayer1: editingScore1 === "" ? null : Number(editingScore1),
        scorePlayer2: editingScore2 === "" ? null : Number(editingScore2),
      });

      setShowEditResultDialog(false);
      setEditingMatch(null);
      setEditingWinnerSlot("player1");
      setEditingScore1("");
      setEditingScore2("");
    } catch (error) {
      console.error(error);
      alert("Ergebnis konnte nicht gespeichert werden.");
    }
  }, [tournamentId, editingMatch, editingWinnerSlot, editingScore1, editingScore2]);

  const handleReleaseBoard = useCallback(
    async (board, currentMatch) => {
      try {
        if (!tournamentId || !board?.id) return;

        const reallyRelease = window.confirm(
          `Board ${board.name || board.boardId || board.id} wirklich freigeben?`,
        );
        if (!reallyRelease) return;

        await db.releaseBoard(tournamentId, board.id);

        if (currentMatch?.id && isLiveMatch(currentMatch)) {
          await db.setMatchAborted(tournamentId, currentMatch.id, {
            boardId: null,
            lobbyId: null,
          });
        }
      } catch (error) {
        console.error(error);
        alert("Board konnte nicht freigegeben werden.");
      }
    },
    [tournamentId],
  );

  const selectedBoardName = useMemo(() => {
    const board = freeBoards.find((item) => item.id === selectedBoardId);
    return board?.name || board?.boardId || "";
  }, [freeBoards, selectedBoardId]);

  const tournamentFinished = useMemo(() => isTournamentFinished(matches), [matches]);

  const renderHome = () => {
    if (screen === "join") {
      return (
        <div className="start-screen">
          <div className="start-card">
            <div className="start-card-head">
              <div>
                <h2>AutoDarts Turnier beitreten</h2>
                <div className="start-subtitle">Öffne ein bestehendes Turnier über den Turniercode.</div>
                <div className="start-subtitle">Turniername: {tournamentName || "Mein Turnier"} · {tournamentEnvironment === "online" ? "Online" : "Offline"}</div>
              </div>
            </div>

            <div className="config-sections">
              <div className="config-card join-card">
                <div className="config-card-title">Turnier öffnen</div>
                <div className="join-row">
                  <input
                    value={joinCode}
                    onChange={(e) => setJoinCode(e.target.value)}
                    placeholder="Turniercode eingeben"
                  />
                  <button onClick={joinTournament} disabled={joiningTournament}>
                    {joiningTournament ? "Lade..." : "Beitreten"}
                  </button>
                </div>
              </div>

              <div className="actions">
                <button className="secondary-btn" onClick={() => setScreen("home")}>
                  Zurück
                </button>
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (screen === "create") {
      return (
        <div className="tournament-layout">
          <div className="players-panel">
            <div className="panel-header">
              <div>
                <h2>Spieler</h2>
                <div className="panel-subtitle">Spielerliste für das neue Turnier</div>
              </div>
              <div className="players-count-badge">{players.length}</div>
            </div>

            <div className="player-add-row">
              <input
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                placeholder="Spielername eingeben"
                onKeyDown={(e) => {
                  if (e.key === "Enter") addPlayer();
                }}
              />
              <button onClick={addPlayer}>Hinzufügen</button>
            </div>

            <div className="players-list">
              {players.map((player) => (
                <div className="player-item" key={player}>
                  <span>{player}</span>
                  <button className="remove-btn" onClick={() => removePlayer(player)}>
                    ×
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="tournament-container">
            <div className="form-topbar">
              <button className="secondary-btn" onClick={() => setScreen("home")}>
                Zurück
              </button>
            </div>

            <div className="form-hero">
              <h2>AutoDarts Turnier erstellen</h2>
              <div className="panel-subtitle">Erstelle ein KO- oder Gruppen-Turnier für Autodarts.</div>
              <div className="panel-subtitle">Typ: {tournamentEnvironment === "online" ? "Online" : "Offline"} (Platzhalter)</div>
            </div>

            <div className="config-sections">
              <div className="config-card">
                <div className="config-card-title">Allgemein</div>
                <div className="grid">
                  <div className="field">
                    <label>Turniername</label>
                    <input value={tournamentName} onChange={(e) => setTournamentName(e.target.value)} />
                  </div>

                  <div className="field">
                    <label>Turniermodus</label>
                    <select value={mode} onChange={(e) => setMode(e.target.value)}>
                      <option value="KO">KO</option>
                      <option value="GROUP_KO">Gruppen + KO</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="config-card">
                <div className="config-card-title">Spiel-Einstellungen</div>
                <div className="grid">
                  <div className="field">
                    <label>Startscore</label>
                    <select value={baseScore} onChange={(e) => setBaseScore(Number(e.target.value))}>
                      {SCORE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>In</label>
                    <select value={inMode} onChange={(e) => setInMode(e.target.value)}>
                      {MODE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>Out</label>
                    <select value={outMode} onChange={(e) => setOutMode(e.target.value)}>
                      {MODE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>Maximale Runden</label>
                    <select value={maxRounds} onChange={(e) => setMaxRounds(Number(e.target.value))}>
                      {MAX_ROUNDS_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>Bull-Modus</label>
                    <select value={bullMode} onChange={(e) => setBullMode(e.target.value)}>
                      {BULL_MODE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>Bull-Off</label>
                    <select value={bullOffMode} onChange={(e) => setBullOffMode(e.target.value)}>
                      {BULL_OFF_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>Match-Modus</label>
                    <select value={matchMode} onChange={(e) => setMatchMode(e.target.value)}>
                      {MATCH_MODE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  {matchMode === "Legs" ? (
                    <div className="field">
                      <label>Best of Legs</label>
                      <select value={legs} onChange={(e) => setLegs(Number(e.target.value))}>
                        {LEGS_OPTIONS.map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    </div>
                  ) : (
                    <>
                      <div className="field">
                        <label>Best of Sets</label>
                        <select value={sets} onChange={(e) => setSets(Number(e.target.value))}>
                          {SETS_OPTIONS.map((option) => (
                            <option key={option} value={option}>
                              {option}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="field">
                        <label>Legs pro Set</label>
                        <select
                          value={legsOfSet}
                          onChange={(e) => setLegsOfSet(Number(e.target.value))}
                        >
                          {LEGS_OF_SET_OPTIONS.map((option) => (
                            <option key={option} value={option}>
                              {option}
                            </option>
                          ))}
                        </select>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {mode === "GROUP_KO" && (
                <div className="config-card">
                  <div className="config-card-title">Gruppenphase</div>
                  <div className="grid">
                    <div className="field">
                      <label>Spieler pro Gruppe</label>
                      <select value={groupSize} onChange={(e) => setGroupSize(Number(e.target.value))}>
                        {GROUP_SIZE_OPTIONS.map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="field">
                      <label>Qualifikanten pro Gruppe</label>
                      <select
                        value={qualifiers}
                        onChange={(e) => setQualifiers(Number(e.target.value))}
                      >
                        {QUALIFIER_OPTIONS.map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              <div className="config-card">
                <div className="config-card-title">Verfügbare Autodarts-Boards</div>
                {loadingBoards ? (
                  <div className="panel-subtitle">Boards werden geladen…</div>
                ) : (
                  <div className="players-list">
                    {allBoards.map((board) => {
                      const isSelected = boards.some(
                        (selected) => selected.id === board.id || selected.boardId === board.id,
                      );

                      return (
                        <label key={board.id} className="player-item" style={{ cursor: "pointer" }}>
                          <span>{board.name || board.id}</span>
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={(e) => {
                              setBoards((prev) => {
                                if (e.target.checked) {
                                  return [
                                    ...prev,
                                    { id: board.id, boardId: board.id, name: board.name },
                                  ];
                                }
                                return prev.filter(
                                  (item) => item.id !== board.id && item.boardId !== board.id,
                                );
                              });
                            }}
                          />
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="actions">
                <button className="secondary-btn" onClick={() => setScreen("home")}>
                  Zurück
                </button>
                <button onClick={createTournament} disabled={creatingTournament}>
                  {creatingTournament ? "Erstelle..." : "Turnier erstellen"}
                </button>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="start-screen">
        <div className="start-card">
          <div className="start-card-head">
            <div>
              <h2>AutoDarts Turnier</h2>
              <div className="start-subtitle">Turnier erstellen oder bestehendem Turnier beitreten.</div>
            </div>
          </div>

          <div className="config-sections start-home-sections">
            <div className="config-card">
              <div className="config-card-title">Start</div>
              <div className="grid">
                <div className="field">
                  <label>Turniername</label>
                  <input
                    value={tournamentName}
                    onChange={(e) => setTournamentName(e.target.value)}
                    placeholder="Turniername eingeben"
                  />
                </div>

                <div className="field">
                  <label>Typ</label>
                  <div className="environment-toggle" role="group" aria-label="Online oder Offline auswählen">
                    <button
                      type="button"
                      className={`environment-option ${tournamentEnvironment === "online" ? "active" : ""}`.trim()}
                      onClick={() => setTournamentEnvironment("online")}
                    >
                      Online
                    </button>
                    <button
                      type="button"
                      className={`environment-option ${tournamentEnvironment === "offline" ? "active" : ""}`.trim()}
                      onClick={() => setTournamentEnvironment("offline")}
                    >
                      Offline
                    </button>
                  </div>
                  <div className="panel-subtitle">Aktuell nur Platzhalter, noch ohne Logik.</div>
                </div>
              </div>
            </div>

            <div className="start-option-grid">
              <button type="button" className="start-option-card" onClick={() => setScreen("create")}>
                <span className="start-option-title">Turnier erstellen</span>
                <span className="start-option-text">{tournamentName || "Mein Turnier"} als {tournamentEnvironment === "online" ? "Online" : "Offline"} öffnen.</span>
              </button>

              <button type="button" className="start-option-card" onClick={() => setScreen("join")}>
                <span className="start-option-title">Turnier beitreten</span>
                <span className="start-option-text">Mit Turniercode {tournamentName || "Mein Turnier"} beitreten.</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderTournament = () => (
    <div className="tournament-bracket-only">
      <div className="bracket-page-shell">
        <div className="bracket-hero">
          <div className="bracket-header">
            <div>
              <h2>
                {tournamentName}
                {tournamentCode && <span className="code-badge">Code: {tournamentCode}</span>}
              </h2>
              <div className="bracket-subtitle">
                {mode === "KO" ? "KO-Turnier" : "Gruppenphase mit KO-Finalrunde"}
              </div>
            </div>

            <div className="bracket-header-actions">
              <button className="secondary-btn" onClick={() => setShowSettingsDialog(true)}>
                Einstellungen
              </button>
              <button className="secondary-btn" onClick={handleLeaveTournament}>
                Turnier verlassen
              </button>
            </div>
          </div>

          <OverviewStats
            matches={matches}
            boards={boards}
            playersCount={playerDocs.length}
            mode={mode}
          />
        </div>

        <BoardOverview boards={boards} matches={matches} onReleaseBoard={handleReleaseBoard} />

        <TournamentTree
          matches={matches}
          groups={groups}
          mode={mode}
          matchMode={matchMode}
          qualifiedPerGroup={qualifiers}
          onStartMatch={handleStartMatch}
          onGiveUpMatch={handleGiveUpMatch}
          onEditResult={handleOpenEditResult}
          onRestartMatch={handleRestartMatch}
          onAbortLiveMatch={handleAbortLiveMatch}
        />

        <FinalStandingsTable
          matches={matches}
          players={playerDocs}
          tournamentName={tournamentName}
        />
      </div>
    </div>
  );

  if (isRestoringTournament) {
    return (
      <div className="tournament-layout">
        <div className="tournament-container">
          <div className="output">Letztes Turnier wird geladen...</div>
        </div>
      </div>
    );
  }

  return (
    <>
      {screen === "tournament" ? renderTournament() : renderHome()}

      {showSettingsDialog && (
        <div className="board-dialog-overlay">
          <div
            className="board-dialog"
            style={{
              width: "min(920px, calc(100vw - 40px))",
              maxHeight: "85vh",
              overflowY: "auto",
            }}
          >
            <h3>Turniereinstellungen bearbeiten</h3>
            <div className="board-dialog-subtitle">
              Gespeicherte Einstellungen ändern und für neue Spiele übernehmen.
            </div>

            <div className="config-sections settings-editor-grid">
              

              <div className="config-card">
                <div className="config-card-title">Spiel-Einstellungen</div>
                <div className="grid">
                  <div className="field">
                    <label>Startscore</label>
                    <select
                      value={baseScore}
                      onChange={(e) => setBaseScore(Number(e.target.value))}
                    >
                      {SCORE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>In</label>
                    <select value={inMode} onChange={(e) => setInMode(e.target.value)}>
                      {MODE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>Out</label>
                    <select value={outMode} onChange={(e) => setOutMode(e.target.value)}>
                      {MODE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>Maximale Runden</label>
                    <select
                      value={maxRounds}
                      onChange={(e) => setMaxRounds(Number(e.target.value))}
                    >
                      {MAX_ROUNDS_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>Bull-Modus</label>
                    <select value={bullMode} onChange={(e) => setBullMode(e.target.value)}>
                      {BULL_MODE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>Bull-Off</label>
                    <select value={bullOffMode} onChange={(e) => setBullOffMode(e.target.value)}>
                      {BULL_OFF_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="field">
                    <label>Match-Modus</label>
                    <select value={matchMode} onChange={(e) => setMatchMode(e.target.value)}>
                      {MATCH_MODE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  {matchMode === "Legs" ? (
                    <div className="field">
                      <label>Best of Legs</label>
                      <select value={legs} onChange={(e) => setLegs(Number(e.target.value))}>
                        {LEGS_OPTIONS.map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    </div>
                  ) : (
                    <>
                      <div className="field">
                        <label>Best of Sets</label>
                        <select value={sets} onChange={(e) => setSets(Number(e.target.value))}>
                          {SETS_OPTIONS.map((option) => (
                            <option key={option} value={option}>
                              {option}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="field">
                        <label>Legs pro Set</label>
                        <select
                          value={legsOfSet}
                          onChange={(e) => setLegsOfSet(Number(e.target.value))}
                        >
                          {LEGS_OF_SET_OPTIONS.map((option) => (
                            <option key={option} value={option}>
                              {option}
                            </option>
                          ))}
                        </select>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="board-dialog-actions">
              <button className="secondary-btn" onClick={() => setShowSettingsDialog(false)}>
                Schließen
              </button>
              <button
                className="start-match-btn"
                onClick={async () => {
                  await handleSaveTournamentSettings();
                  setShowSettingsDialog(false);
                }}
              >
                Einstellungen speichern
              </button>
            </div>
          </div>
        </div>
      )}

      {showBoardDialog && (
        <div className="board-dialog-overlay">
          <div className="board-dialog">
            <h3>Board auswählen</h3>
            <div className="board-dialog-subtitle">
              Wähle ein freies Board für Spiel {selectedMatch?.matchNumber}.
            </div>

            <div className="field">
              <label>Freies Board</label>
              <select value={selectedBoardId} onChange={(e) => setSelectedBoardId(e.target.value)}>
                {freeBoards.map((board) => (
                  <option key={board.id} value={board.id}>
                    {board.name || board.boardId || board.id}
                  </option>
                ))}
              </select>
            </div>

            <div className="board-dialog-subtitle" style={{ marginTop: 12 }}>
              Ausgewählt: <strong>{selectedBoardName || "—"}</strong>
            </div>

            <div className="board-dialog-actions">
              <button
                className="secondary-btn"
                onClick={() => {
                  setShowBoardDialog(false);
                  setSelectedBoardId("");
                  setSelectedMatch(null);
                }}
              >
                Abbrechen
              </button>

              <button className="start-match-btn" onClick={confirmStartMatch}>
                Spiel starten
              </button>
            </div>
          </div>
        </div>
      )}

      {showEditResultDialog && editingMatch && (
        <div className="board-dialog-overlay">
          <div className="board-dialog">
            <h3>Ergebnis bearbeiten</h3>
            <div className="board-dialog-subtitle">
              Spiel {editingMatch.matchNumber}: {getDisplayName(editingMatch.player1)} gegen{" "}
              {getDisplayName(editingMatch.player2)}
            </div>

            <div className="field">
              <label>Sieger</label>
              <select
                value={editingWinnerSlot}
                onChange={(e) => setEditingWinnerSlot(e.target.value)}
              >
                <option value="player1">{getDisplayName(editingMatch.player1)}</option>
                <option value="player2">{getDisplayName(editingMatch.player2)}</option>
              </select>
            </div>

            <div className="dialog-score-grid" style={{ marginTop: 12 }}>
              <div className="field">
                <label>Punkte / Legs Spieler 1</label>
                <input
                  value={editingScore1}
                  onChange={(e) => setEditingScore1(e.target.value)}
                  inputMode="numeric"
                />
              </div>

              <div className="field">
                <label>Punkte / Legs Spieler 2</label>
                <input
                  value={editingScore2}
                  onChange={(e) => setEditingScore2(e.target.value)}
                  inputMode="numeric"
                />
              </div>
            </div>

            <div className="board-dialog-actions">
              <button
                className="secondary-btn"
                onClick={() => {
                  setShowEditResultDialog(false);
                  setEditingMatch(null);
                  setEditingWinnerSlot("player1");
                  setEditingScore1("");
                  setEditingScore2("");
                }}
              >
                Schließen
              </button>

              <button className="start-match-btn" onClick={handleSaveEditedResult}>
                Speichern
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
